@extends('templates.main')
@section('title')
about
@endsection

@section('heading')
about heading
@endsection

@section('content')
<h1>about body</h1>
@endsection