@extends('layouts.main')
@section('title')
hello
@endsection

@section('heading')
<h1>hi</h1>
@endsection

@section('body')
<h1>vehle bande</h1>
@endsection