

<?php
session_start();
$errormsg="";
if(isset($_SESSION['usr_id'])!="") {
	header("Location: index.php");
}

include_once 'Connections/connuser.php';

//check if form is submitted
if (isset($_POST['login'])) {

	$email = mysqli_real_escape_string($con, $_POST['email']);
	$password = mysqli_real_escape_string($con, $_POST['password']);
	
	$c=mysqli_query($con,"SELECT refid FROM users WHERE email = '" . $email. "' and password = '" . md5($password) . "'");
	$d=mysqli_query($con,"SELECT empid FROM roles WHERE email = '" . $email. "' and password = '" . md5($password) . "'");

	if(mysqli_num_rows($c) > 0)
	{

		$count=mysqli_query($con, "SELECT * FROM users WHERE email = '" . $email. "' and password = '" . md5($password) . "' and status='1'");
		
		
		if ($row = mysqli_fetch_array($count)) 
		{
			
			$_SESSION['usr_id'] = $row['email'];
			$_SESSION['usr_name'] = $row['fname']." ".$row['lname'];
			
			header("Location: index.php");
		}
		else 
		{
			$errormsg = "Please activate Your Account.... <a href='activation.php'>Click Here</a>";
		}	
    

    }
	else if(mysqli_num_rows($d) > 0)
	{

		$count=mysqli_query($con, "SELECT * FROM roles WHERE email = '" . $email. "' and password = '" . md5($password) . "' and status='1'");
		
		
		if ($row = mysqli_fetch_array($count)) 
		{
			$_SESSION['usr_id'] = $row['email'];
			$_SESSION['usr_name'] = $row['fname']." ".$row['lname'];
			$_SESSION['page'] = $row['role'];
			if($row['role']=="Dean")
			{				
				header("Location: Dean.php");
			}
			else if($row['role']=="Inspmember")
			{				
				header("Location: inspmember.php");
			}
			else if($row['role']=="Inshead")
			{				
				header("Location: insphead.php");
			}
			else if($row['role']=="Admin")
			{				
				header("Location: Admin.php");
			}
			else if($row['role']=="Clerk")
			{				
				header("Location: Clerk.php");
			}
		}
		else 
		{
			$errormsg = "Please activate Your Account.... <a href='activation.php'>Click Here</a>";
		}	
    

    }
    else
    {
	$errormsg = "Incorrect Email or Password!!!";
    }
	
	
}
?>



<!DOCTYPE html>

<html lang="en"><!-- InstanceBegin template="/Templates/puptemplate.dwt" codeOutsideHTMLIsLocked="false" --><head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" />
<!-- InstanceBeginEditable name="doctitle" --><title>Sign-Up/Login Form</title>
<!-- InstanceEndEditable -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">


<link href="Content/Site.css" rel="stylesheet"/>
<link href="http://pupadmissions.ac.in/favicon.ico" rel="shortcut icon" type="image/x-icon" />
<link href="Content/bootstrap.css" rel="stylesheet" />
<link href="Content/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet" />
<script src="Scripts/bootstrap.min.js"></script>
<script src="Scripts/jquery-1.10.2.min.js"></script>
<script src="Scripts/jquery-1.10.2.js" type="text/javascript"></script>
<script src="Scripts/bootstrap.js" type="text/javascript"></script>
<script src="Scripts/respond.js" type="text/javascript"></script>
<script src="bundles/WebFormsJs.JS" type="text/javascript"></script>


<script src="Scripts/bootstrap-select.js" type="text/javascript"></script>


<link href="Content/bootstrap-select.css" rel="stylesheet"/>

      <!-- InstanceBeginEditable name="head" -->
      
      
  <link href='login/css/css.css' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="login/css/normalize.min.css">

  
      <link rel="stylesheet" href="login/css/style.css">
      <style type="text/css">
      body,td,th {
	font-family: "Titillium Web", sans-serif;
	color: #FFFFFF;
}
      .white {
	color: #FFFFFF;
}
      </style>
      <!-- InstanceEndEditable -->
</head>
<body>
    


<!-- InstanceBeginEditable name="header file" --><?php include'header.php' ?><!-- InstanceEndEditable -->








        


    <h3 class="alert alert-info text-center text-capitalize timestext"><strong>Welcome to Punjabi University Patiala New college RegistrationYear 2017-18</strong>  </h3>
    

    <div class="row text-center " style="display: none;">
        <a href="http://pupadmissions.ac.in/Onlineregistration.aspx">
            <img alt="New Registration" src="images/newuserregistration.png" /></a>

    </div>


    <div class="row text-center">


        
    <div class="row text-justify">
        <div class="col-md-12">
            <div class="panel panel-primary">
            
                <div class="panel-heading"><strong><!-- InstanceBeginEditable name="content_head" -->Login Here<!-- InstanceEndEditable --></strong></div>
                <div class="panel-body text-info">

                   <!-- InstanceBeginEditable name="content_body" --><style>
				   
  .btn-success {
      box-shadow: 1px 2px 5px #000000;   
  }</style> 
                   <div class="container"> 
          <form class="form-horizontal" role="form" action="" method="post" name="loginform">
  <div class="form-group">
    <label class="control-label col-sm-2" for="email">Email:</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" id="email1" name="email" placeholder="Enter email">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="password1">Password:</label>
    <div class="col-sm-10"> 
      <input type="password" class="form-control" id="password1" name="password" placeholder="Enter password">
    </div>
  </div>
  
  <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit"  name="login" class="btn btn-success">Submit</button>
    </div>
  </div>
  <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      Already Registered? <a href="login.php" class="active">Login Here</a>
    </div>
  </div>
  <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      <span style="color:#F00";><?php echo $errormsg; ?></span>
    </div>
  </div>
  
</form></div><form>
 <!-- /form --><!-- InstanceEndEditable -->
              </div>
              </div>
              </div>
              </div>
                
        <div class="row text-justify">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading text-uppercase"><strong>Additional</strong></div>
                <div class="panel-body text-info">




                    
                    <!--<hr class="redhr" >-->

                    
                </div>
            </div>
        </div>
    </div>
<script src="Scripts/backtotop.js"></script>
    

                </div>
            <hr class="hidden-print"/>
            <footer class="hidden-print">
                <p>&copy; 2017 - Punjabi University, Patiala</p>
            </footer>
    
</body>
<!-- InstanceEnd --></html>