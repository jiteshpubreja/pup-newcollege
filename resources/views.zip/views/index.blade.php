@extends('templates.main')

@section('heading')
New Hello
@endsection
@section('content')
<b>Vehle Bande</b>
@endsection